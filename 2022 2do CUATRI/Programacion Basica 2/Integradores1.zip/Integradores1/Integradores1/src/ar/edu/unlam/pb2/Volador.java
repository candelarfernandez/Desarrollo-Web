package ar.edu.unlam.pb2;

public interface Volador  {

	Double getAltura();	
	

}
