package ar.edu.unlam.pb2;

public interface Acuatico {
	Double getProfundidad();

}
