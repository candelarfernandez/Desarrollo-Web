package ar.edu.unlam.pb2;

public class VehiculoInexistenteException extends Exception {

	

	public  VehiculoInexistenteException(String string) {
		string="Vehiculo inexistente";
	}

}
