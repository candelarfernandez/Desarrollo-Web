package ar.edu.unlam.pb2;

public enum TipoDeBatalla {
	AEREA, TERRESTRE, ACUATICA, NAVAL
	
	

}
