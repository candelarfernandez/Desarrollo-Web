package ar.edu.unlam.pb2;

public interface Terrestre {
	
	Double getVelocidad();

}
