package ar.edu.unlam.pb2;

public class VehiculoIncompatibleException extends Exception {



	public VehiculoIncompatibleException(String string) {
		string="vehiculo inexistente";
	}

}
