package ar.edu.unlam.pb2;

public class YaExisteTitular extends Exception{
	
	public YaExisteTitular (String string){
		super("Dni Duplicado");
	}

}
