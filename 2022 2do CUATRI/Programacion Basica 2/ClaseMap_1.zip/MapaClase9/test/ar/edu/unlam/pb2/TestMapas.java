package ar.edu.unlam.pb2;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestMapas {

	@Test
	public void test() {
	
		/*Los maps tienen dos valores: 
		 * Map <key,value>;
		 * Map <Integer, Alumno>
		 * key: buscar el objeto (ej buscar un dni)
		 * value: valor de referencia (devuelve al alumno de ese dni)
		 * si no lo encuentra al alumno, retorno una exepcion 
		 * la key no se puede repetir, el value todas las veces que quiera*/
	}

}
