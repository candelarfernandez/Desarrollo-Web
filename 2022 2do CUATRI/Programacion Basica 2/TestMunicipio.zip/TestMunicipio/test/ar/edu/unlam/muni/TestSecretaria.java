package ar.edu.unlam.muni;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestSecretaria {
	
	@Test
	public void queSePuedaCrearUnaSecretaria(){
		Secretaria secretaria = new Secretaria("Cordoba");
		assertNotNull(secretaria);
	}
	
	// linked list 
	@Test
	public void queSePuedaAgregarUnHabitanteALaSecretaria(){
		Integer dni = 5;
		String nombre = "Juan";
		String calle= "Florencio varela";
		Integer numero= 1900;
		Integer numeroMunicipio=1;
		String nombreMunicipio= "San justo";
		Municipio municipio= new Municipio(numeroMunicipio, nombreMunicipio);
		Vivienda vivienda = new Vivienda(calle, numero, municipio);
		Habitante habitante = new Habitante(dni, nombre, vivienda);
		
		Secretaria secretaria = new Secretaria("Cordoba");
		secretaria.agregarhabitante(habitante);
		Integer valorEsperado=1;
		Integer valorObtenido= secretaria.getHabitantes().size();
		assertEquals(valorEsperado, valorObtenido);
	}
	

}
