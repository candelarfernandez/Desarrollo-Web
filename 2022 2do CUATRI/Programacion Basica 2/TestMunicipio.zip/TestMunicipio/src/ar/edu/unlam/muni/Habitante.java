package ar.edu.unlam.muni;

public class Habitante {
	private Integer dni;
	private String nombre;
	private Vivienda vivienda;

	public Habitante(Integer dni, String nombre, Vivienda vivienda) {
		this.dni=dni;
		this.nombre=nombre;
		this.vivienda=vivienda;
		
	}

}
