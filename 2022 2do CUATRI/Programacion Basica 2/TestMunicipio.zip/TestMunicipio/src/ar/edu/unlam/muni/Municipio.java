package ar.edu.unlam.muni;

public class Municipio {

	private Integer numeroMunicipio;
	private String nmbreMunicipio;

	public Municipio(Integer numeroMunicipio, String nombreMunicipio) {
		this.numeroMunicipio=numeroMunicipio;
		this.nmbreMunicipio=nombreMunicipio;
		
	}

}
