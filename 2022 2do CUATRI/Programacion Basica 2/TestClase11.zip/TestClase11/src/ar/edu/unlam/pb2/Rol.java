package ar.edu.unlam.pb2;

public enum Rol {
	
	TRAFICO, RAMPA, LEAD;

}
