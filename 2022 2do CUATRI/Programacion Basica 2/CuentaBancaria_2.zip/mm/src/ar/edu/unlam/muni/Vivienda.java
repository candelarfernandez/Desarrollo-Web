package ar.edu.unlam.muni;

public class Vivienda {
	private String calle;
	private Integer numero;
	private String municipio;
	private Integer id;

	public Vivienda(String calle, Integer numero, String municipio, Integer id) {
		this.calle=calle;
		this.numero=numero;
		this.municipio=municipio;
		this.id=id;
	}

}
