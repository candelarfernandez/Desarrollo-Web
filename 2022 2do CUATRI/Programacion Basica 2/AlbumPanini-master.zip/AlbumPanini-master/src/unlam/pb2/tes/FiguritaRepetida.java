package unlam.pb2.tes;

public class FiguritaRepetida extends Exception {
String mensaje ="Figurita repetida";
}
