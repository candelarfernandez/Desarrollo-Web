package unlam.pb2.tes;

public class FiguritaNoDisponible extends Exception {

}
