package unlam.pb2.tes;

public enum Estado {
	pegada, sinPegar;

}
