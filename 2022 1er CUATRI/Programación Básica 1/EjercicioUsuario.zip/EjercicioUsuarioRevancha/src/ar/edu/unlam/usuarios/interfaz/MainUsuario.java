package ar.edu.unlam.usuarios.interfaz;

import java.util.Scanner;

import ar.edu.unlam.usuarios.dominio.Sistema;
import ar.edu.unlam.usuarios.dominio.Usuario;

public class MainUsuario {
	
	static Scanner teclado = new Scanner(System.in);

	public static void main(String[] args) {
		Sistema nuevoSistema = crearSistema();
		menuGeneral(nuevoSistema);

	}

	private static void menuGeneral(Sistema nuevoSistema) {
		int opcion = 0;
		do {System.out.println("*****************************");
			System.out.println("Bienvenidos al menu!");
			System.out.println("Elija la opcion 1 para registrarse "
					+ "\nElija la opcion 2 para iniciar sesion "
					+ "\nElija la opcion 3 para mostrar los usuarios ");
			opcion = teclado.nextInt();
		switch(opcion) {
		case 1: menuRegistrar(nuevoSistema);
		break;
		case 2: menuIngresar(nuevoSistema);
		break;
		case 3: mostrarUsuarios(nuevoSistema.getUsuarios());
		break;
		case 0: System.out.println("Usted ha salido del sistema");
		break;
		default:
			System.out.println("Opcion invalida");
		break;
		}

		}while(opcion !=0);
		
	}
	
	private static String mostrarUsuarios(Usuario[] usuarios) {
		String lista ="";
		for(int i=0; i<usuarios.length;i++) {
			if(usuarios[i] != null)
			lista += usuarios[i].getNombre() +"\n";
			
		}
		return lista;
	}

	

	private static void menuIngresar(Sistema nuevoSistema) {
		int opcion =0;
		do {System.out.println("*****************************");
		System.out.println("Bienvenidos al menu de ingreso!");
		System.out.println("Elija la opcion 1 para iniciar sesion "
				+ "\nElija la opcion 0 para volver al menu anterior"
				+ "\n*****************************");
		opcion = teclado.nextInt();
		switch(opcion) {
		case 1: 
			System.out.println("*****************************");
			System.out.println("Ingrese el nombre del usuario");
			String usuario = teclado.next();
			System.out.println("Ingrese la contrasenia del usuario");
			String contrasenia = teclado.next();
			
			if(nuevoSistema.loguearUsuario(usuario, contrasenia)) {
				System.out.println("El usuario ha iniciado sesión correctamente");
			}
			else {
				System.out.println("No se pudo iniciar sesión");
			}
			
			break;
		case 0: menuGeneral(nuevoSistema);
			break;
		}
			
		}while(opcion !=0);
		
		
	}

	private static void menuRegistrar(Sistema nuevoSistema) {
		int opcion =0;
		do {System.out.println("*****************************");
		System.out.println("Bienvenidos al menu registrar!");
		System.out.println("Elija la opcion 1 para registrarse "
				+ "\nElija la opcion 0 para volver al menu anterior"
				+ "\n*****************************");
		opcion = teclado.nextInt();
		switch(opcion) {
		case 1: 
			System.out.println("*****************************");
			System.out.println("Ingrese el nombre del usuario");
			String usuario = teclado.next();
			System.out.println("Ingrese la contrasenia del usuario");
			String contrasenia = teclado.next();
			System.out.println("Ingrese el nombre");
			String nombre = teclado.next();
			System.out.println("Ingrese el apellido");
			String apellido = teclado.next();
			System.out.println("Ingrese el dni del usuario");
			int dni = teclado.nextInt();
			System.out.println("Ingrese la edad del usuario");
			int edad = teclado.nextInt();
			System.out.println("*****************************");
			
			Usuario usuarios = new Usuario(usuario, contrasenia, nombre, apellido, dni, edad);
			
			if(nuevoSistema.ingresarUsuario(usuarios)) {
				System.out.println("El usuario se ha agregado correctamente");
			}
			else {
				System.out.println("No se pudo agregar el usuario");
			}
			break;
		case 0: menuGeneral(nuevoSistema);
			break;
		}
		}while(opcion !=0);
		
	}

	private static Sistema crearSistema() {
		System.out.println("*****************************");
		System.out.println("Bienvenidos al sistema");
		System.out.println("Ingresar nombre del sistema");
		String nombreDelSistema = teclado.next();
		System.out.println("Ingresar cantidad de usuarios");
		int cantidadUsuarios = teclado.nextInt();
		System.out.println("*****************************");
		return new Sistema(nombreDelSistema, cantidadUsuarios);
	}

}
