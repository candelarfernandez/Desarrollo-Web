
package ar.edu.unlam.usuarios.dominio;

public class Sistema {
	
	private String nombreDelSistema;
	private Usuario[] usuarios;
	
	public Sistema(String nombreDelSistema, int cantidadUsuarios) {
		this.nombreDelSistema= nombreDelSistema;
		this.setUsuarios(new Usuario[cantidadUsuarios]);
		
	}
	
	public boolean esMayorDeEdad(Usuario nuevoUsuario) {
		int contadorMayoresEdad=0;
		for(int i=0;i<getUsuarios().length;i++) {
			if(getUsuarios()[i].getEdad()>=18) {
				contadorMayoresEdad++;
				return true;
			}
		}
		return false;
		
	}
	
	

	public boolean ingresarUsuario(Usuario nuevoUsuario) {
	if(usuarioExistente(nuevoUsuario))
			if(laContraseniaEsValida(nuevoUsuario))
		       for(int i=0; i<getUsuarios().length;i++) {
			if(getUsuarios()[i] == null) {
				getUsuarios()[i] = nuevoUsuario;
				return true;
			}
		}
		return false;
	}
	
	public boolean usuarioExistente(Usuario nuevoUsuario) {
		
		for(int i=0; i<getUsuarios().length;i++) {
			if(getUsuarios()[i] != null)
			if(getUsuarios()[i].getUsuario().equals(nuevoUsuario.getUsuario())) {
				return false;
			}
			
		}
		return true;
	}
	
	public boolean laContraseniaEsValida(Usuario nuevoUsuario) {
		for(int i=0;i<getUsuarios().length;i++) {
			if(laContraseniaesValidaOchoDigitos(nuevoUsuario)) {
				return true;
			}
		}
		return false;
	}
	
	public boolean laContraseniaNumerico(Usuario nuevoUsuario) {
		final int MIN_ENTEROS=2;
		int counterEnteros=0;
	
		for(int i=0;i<getUsuarios().length;i++) {
			char palabra = nuevoUsuario.getContrasenia().charAt(i);
			if(Character.isDigit(palabra)) {
				counterEnteros++;
				
			if(counterEnteros>= MIN_ENTEROS) {
			    return true;
			}
		
		  }
		}
		return false;
	}
	
	public boolean laContraseniaesValidaOchoDigitos(Usuario nuevoUsuario) {
		for(int i=0; i<getUsuarios().length;i++) {
			if(nuevoUsuario.getContrasenia().length()>=8) {
				return true;
			}
			else {
				System.out.println("La contrasenia es invalida");
			}
		}
		return false;
	}
	public boolean laContraseniaesValidaCaracterNumerico(Usuario nuevoUsuario) {
		final int MIN_ENTEROS=3;
		int contadorEnteros=0; 
		for(int i=0; i<nuevoUsuario.getUsuario().length();i++) {
			char letra= nuevoUsuario.getUsuario().charAt(i);
			if(letra>48 && letra<57) {
				contadorEnteros++;
			}
		
			if(contadorEnteros>=MIN_ENTEROS) {
				return true;
			}
		}
		
		return false;
	}
	
	public boolean caracterMinuscula(Usuario nuevoUsuario) {
		final int MIN_LOWERCASE=1;
		int lowercaseCounter=0;
		for(int i=0;i<getUsuarios().length;i++) {
			char letra=nuevoUsuario.getContrasenia().charAt(i);
			if(Character.isLowerCase(letra)) {
				lowercaseCounter++;
				return true;
			}
		}
		return false;
	}
	
	public boolean caracterMayuscula(Usuario nuevoUsuario) {
		final int MIN_UPPERCASE=1;
		int uppercaseCounter=0;
		for(int i=0;i<getUsuarios().length;i++) {
			char letra = nuevoUsuario.getContrasenia().charAt(i);
			if(Character.isUpperCase(letra)) {
				uppercaseCounter++;
				return true;
			}
		}
		return false;
	}
	
	public boolean verificarSiContieneArroba(Usuario nuevoUsuario) {
		String palabra="";
		for(int i=0;i<getUsuarios().length;i++) {
			palabra=nuevoUsuario.getContrasenia();
			if(palabra.charAt(i) == '@') {
				return true;
			}
		}
		return false;
	}
	
	public boolean verificarSiContieneArrobaEnPrimeraOUltima(Usuario nuevoUsuario) {
		String palabra = "";
		for(int i=0;i<getUsuarios().length;i++) {
			palabra=nuevoUsuario.getContrasenia();
			if(palabra.charAt(0) != '@' && palabra.charAt(palabra.length()-1) != '@')
				return true;
		}
		return false;
	}



	public boolean loguearUsuario(String usuario, String contrasenia) {
		for(int i=0; i<getUsuarios().length;i++) {
			if(getUsuarios()[i].getUsuario()!= null  && getUsuarios()[i].getContrasenia()!= null)
			if(getUsuarios()[i].getUsuario().equals(usuario) && getUsuarios()[i].getContrasenia().equals(contrasenia)) {
				return true;
			}
		}
		return false;
	}
	
	public boolean calcularCantidadDeUsuariosMenores(Usuario nuevoUsuario) {
		int contadorUsuariosMenores=0;
		for(int i=0;i<getUsuarios().length;i++) {
			if(getUsuarios()[i].getEdad()<18) {
				contadorUsuariosMenores++;
				return true;
			}
		}
		return false;
	}
	public boolean calcularCantidadDeUsuariosMayoes(Usuario nuevoUsuario) {
		int contadorUsuariosMayores=0;
		for(int i=0;i<getUsuarios().length;i++) {
			if(getUsuarios()[i].getEdad()>=18) {
				contadorUsuariosMayores++;
				return true;
			}
		}
		return false;
	}
	public int calcularEdadPromedio(Usuario nuevoUsuario) {
		int sumaEdades=0;
		int edadPromedio=0;
		int cantidadUsuarios=0;
		for(int i=0;i<getUsuarios().length;i++) {	
			if(getUsuarios()[i] != null)
		     sumaEdades += getUsuarios()[i].getEdad();
		     cantidadUsuarios++;
		     edadPromedio= sumaEdades /cantidadUsuarios;
		}
		return edadPromedio;
	}
	
	public void listarUsuarios(Usuario[] usuarios) {
		Usuario auxiliar;
		for(int i=1;i<usuarios.length;i++) {
			for(int j=0;i<usuarios.length-1;i++) {
				if(usuarios[i] != null)
				if(usuarios[i].getUsuario().compareTo(usuarios[j+1].getUsuario())>0)
				auxiliar = usuarios[j];
				usuarios[j]=usuarios[j+1];
				auxiliar = usuarios[j+1];
			}
		}
	}

	public Usuario[] getUsuarios() {
		return usuarios;
	}

	public void setUsuarios(Usuario[] usuarios) {
		this.usuarios = usuarios;
	}

	

	

	
	
	

}
