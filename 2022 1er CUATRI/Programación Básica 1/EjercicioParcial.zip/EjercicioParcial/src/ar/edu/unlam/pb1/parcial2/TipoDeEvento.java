package ar.edu.unlam.pb1.parcial2;

public enum TipoDeEvento {
GOL_A_FAVOR,
GOL_EN_CONTRA,
AMONESTACION,
EXPULSION
}
