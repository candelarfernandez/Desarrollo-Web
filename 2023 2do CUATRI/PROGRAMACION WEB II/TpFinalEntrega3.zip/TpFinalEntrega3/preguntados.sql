-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost:3307
-- Tiempo de generación: 18-10-2023 a las 01:08:50
-- Versión del servidor: 10.4.28-MariaDB
-- Versión de PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `preguntados`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `preguntas`
--

CREATE TABLE `preguntas` (
  `pregunta` text NOT NULL,
  `id` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `preguntas`
--

INSERT INTO `preguntas` (`pregunta`, `id`) VALUES
('Si en un script PHP encuentra una llamada a un m?todo de clase de la siguiente manera:\nUsuario::traerUsuario();\nSe trata de:', 1),
('Cuando utilizo una Clase en forma est?tica siempre se ejecuta el m?todo __construct()', 2),
('La S del acr?nimo SOLID es por el concepto Single Responsability, que indica:', 3),
('El concepto de acoplamiento refiere a:', 4),
('Como concepto general podemos decir que a menos acoplamiento mejor software', 5),
('En software se entiende por patr?n de dise?o a:', 6),
('El patr?n MVC se utiliza mucho en aplicaciones web porque:', 7),
('En un modelo MVC el que recibe normalmente la petici?n del cliente es:', 8),
('El modelo en un esquema MVC es el encargado de almacenar y ejecutar la l?gica del negocio', 9),
('Uno de los objetivos del modelo MVC es separar en la aplicaci?n el modelo de negocios de las interfaces de usuario', 10),
('El enrutador en un modelo MVC es el encargado de ejecutar las operaciones de acceso a la base de datos', 11),
('El folding en una aplicaci?n web se refiere a:', 12),
('Si estoy desarrollando usando TDD estoy', 13),
('El patr?n MVC esta compuesto por:', 14),
('En un patr?n MVC la Vista es la encargada de ', 15),
('La principal diferencia entre los enfoques Responsive y Mobile First es', 16),
('La principal diferencia entre una Aplicaci?n Web y una Aplicaci?n monol?tica (por ejemplo una Win32) es:', 17),
('El protocolo a trav?s del cu?l se realiza todo el intercambio de datos entre un servidor web y un cliente es:', 18),
('El protocolo HTTP tiene entre sus caracteristicas ser:', 19),
('El protocolo DNS es:', 20),
('El protocolo HTTP implementa comandos, entre ellos:', 21),
('El protyocolo HTTP implementa codigos de error de respuesta, si recibo un codigo de la serie 500, ha ocurrido:', 22),
('El protyocolo HTTP implementa codigos de error de respuesta, si recibo un codigo de la serie 400, ha ocurrido:', 23),
('El protyocolo HTTP implementa codigos de error de respuesta, si recibo un codigo de la serie 200, ha ocurrido:', 24),
('En una petici?n GET, los parametros de la petici?n se pasan a trav?s de....', 25),
('Se denomina Scripting del lado del cliente, o programaci?n Front-end o Client Side Scripting a :', 26),
('Se denomina Scripting del lado del servidor, o programaci?n Back-end o Server Side Scripting a :', 27),
('La petici?n de un recurso determinado a un sitio Web (imagen, archivo, etc.) se canaliza mediante:', 28);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `respuestas`
--

CREATE TABLE `respuestas` (
  `id` int(10) NOT NULL,
  `idPregunta` int(10) NOT NULL,
  `respuesta` text NOT NULL,
  `esCorrecta` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `respuestas`
--

INSERT INTO `respuestas` (`id`, `idPregunta`, `respuesta`, `esCorrecta`) VALUES
(1, 1, 'Una llamada al m?todo por referencia', 'false'),
(2, 1, 'Un m?tido de una Clase invocado en forma est?tica', 'true'),
(3, 1, 'Llamada a un constructor', 'false'),
(4, 1, 'Instanciaci?n de una Clase', 'false'),
(5, 2, 'VERDADERO', 'false'),
(6, 2, 'FALSO', 'true'),
(7, 3, 'Que una Clase solo debe ser instanciada para poder invocer un m?todo de la misma', 'false'),
(8, 3, 'Que una Clase debe cumplir la mayor cantidad de funciones dentro de mi modelo de negocios', 'false'),
(9, 3, 'Que un objeto/clase debe tener una sola raz?n para cambiar, esto es debe tener un s?lo trabajo', 'true'),
(10, 3, 'Los objetos o clases deben estar abiertos por extensi?n, pero cerrados por modificaci?n.', 'false'),
(11, 4, 'al grado de interdependencia que tienen dos unidades de software entre s?', 'true'),
(12, 4, 'al grado de independencia que tienen dos unidades de software entre s?', 'false'),
(13, 4, 'al grado de comunicaci?n que tienen dos unidades de software entre s?', 'false'),
(14, 4, 'al grado de complejidad que tienen dos unidades de software', 'false'),
(15, 5, 'VERDADERO', 'true'),
(16, 5, 'FALSO', 'false'),
(17, 6, 'Al due?o de un dise?o determinado', 'false'),
(18, 6, 'A un conjunto de t?cnicas aplicadas en conjunto para resolver problemas comunes al desarrollo de software', 'true'),
(19, 6, 'Es la vertienrte de POO que se ocupa del desarrollo de interfaces', 'false'),
(20, 6, 'En POO se denomina as? a una clase que funciona como una librer?a en Porcedural', 'false'),
(21, 7, 'Es mas lindo', 'false'),
(22, 7, 'Es mas simple', 'false'),
(23, 7, 'Representa bien la divisi?n de entornos en una aplicaci?n web', 'true'),
(24, 7, 'Esta desarrollado para explicar las interfaces desde una ?ptica de UX', 'false'),
(25, 8, 'el controlador', 'false'),
(26, 8, 'el modelo', 'false'),
(27, 8, 'la vista', 'false'),
(28, 8, 'el enrutador', 'true'),
(29, 9, 'VERDADERO', 'true'),
(30, 9, 'FALSO', 'false'),
(31, 10, 'VERDADERO', 'true'),
(32, 10, 'FALSO', 'false'),
(33, 11, 'VERDADERO', 'false'),
(34, 11, 'FALSO', 'true'),
(35, 12, 'una forma de disponer de las consultas en la base de datos', 'false'),
(36, 12, 'una forma de escribir el c?digo de manera que sea legible', 'false'),
(37, 12, 'una forma de ordenar el c?digo de manera que el proyecto sea comprensible', 'true'),
(38, 12, 'un m?todo de foldear vistas', 'false'),
(39, 13, 'Usando un m?todo de programaci?n basado en objetos', 'false'),
(40, 13, 'Usando un m?todo de programaci?n basado en funciones', 'true'),
(41, 13, 'Usando un m?todo de programaci?n basado en pruebas', 'false'),
(42, 13, 'Usando un m?todo de programaci?n basado en test', 'false'),
(43, 14, 'Un Modelo, una Vista y un Controlador, complementados por un enrutador', 'true'),
(44, 14, 'Un Modelo, una Vista y un Controlador', 'false'),
(45, 14, 'Un Modelo, una Versionador y un Controlador', 'false'),
(46, 14, 'Un Microservicio, una Vista y un Controlador', 'false'),
(47, 15, 'Resolver la comunicaci?n con el usuario', 'true'),
(48, 15, 'Comunicar al Controlador con el Modelo', 'false'),
(49, 15, 'Resolver la l?gica de negocios', 'false'),
(50, 15, 'Resolver la petici?n del usuario', 'false'),
(51, 16, 'Que el enfoque Mobile First se basa en CSS3 y HTML 5.', 'false'),
(52, 16, 'Que el enfoque Mobile First se basa en la idea de dise?ar pensando en el ambiente m?vil y de all? llevar el dise?o al desktop.', 'true'),
(53, 16, 'En que el enfoque Responsive el sitio debe adaptarse a diferentes dispositivos y en el enfoque Mobile First no.', 'false'),
(54, 16, 'Los dos enfoques son iguales, dos nombres para identificar o mismo.', 'false'),
(55, 16, 'La 1 y 4 son correctas', 'false'),
(60, 17, 'Son escencialmente iguales', 'false'),
(61, 17, 'Que una aplicaci?n web hace uso de una red TCP/IP y una aplicaci?n monol?tica no.', 'false'),
(62, 17, 'Que en una aplicaci?n web es dividida en dos partes interdependientes, una en el cliente (visualizaci?n) y otra en el servidor (l?gica de negocios, acceso a datos, etc.)', 'true'),
(63, 17, '1 y 2 son correctas', 'false'),
(64, 18, 'HTTP/HTTPS', 'true'),
(65, 18, 'DNS/HTTP', 'false'),
(66, 18, 'REST', 'false'),
(67, 18, '1 y 2 son correctas', 'false'),
(68, 19, 'No orientado a la conexi?n (Conectionless) / Sin mantenimiento de estado de conexi?n (Stateless)', 'true'),
(69, 19, 'No orientado a la conexi?n (Conectionless) ', 'false'),
(70, 19, 'Orientado a la conexi?n ', 'false'),
(71, 19, 'Orientado al mantenimiento de estado de conexi?n ', 'false'),
(72, 20, 'Un protocolo de resoluci?n de espacios de procesamiento en un entorno distribuido', 'false'),
(73, 20, 'Un protocolo de cifrado de 3 niveles usado en Internet', 'false'),
(74, 20, 'Un protocolo de comunicaci?n entre sitios web y sus clientes', 'false'),
(75, 20, 'Un protocolo de resoluci?n de nombres de caracteristicas jer?rquicas', 'true'),
(76, 21, 'GET, POST, HEAD', 'true'),
(77, 21, 'SEND, PING, SAVE', 'false'),
(78, 21, 'GET, SEND, PING', 'false'),
(79, 21, 'GET, POST, SEND', 'false'),
(80, 22, 'Nada, informa que el procesamiento finlaizo Ok', 'false'),
(81, 22, 'Informa un error en la resolcu?n DNS del nombre', 'false'),
(82, 22, 'Informa que ha ocurrido un error en el procesamiento de la peticion en el servidor', 'true'),
(83, 22, 'Informa que ha ocurrido un error en el procesamiento de la peticion en el cliente', 'false'),
(84, 23, 'Nada, informa que el procesamiento finlaizo Ok', 'false'),
(85, 23, 'Informa un error en la resolcu?n DNS del nombre', 'false'),
(86, 23, 'Informa que ha ocurrido un error en el procesamiento de la peticion en el servidor', 'false'),
(87, 23, 'Informa que ha ocurrido un error en el procesamiento de la peticion en el cliente', 'true'),
(88, 24, 'Nada, informa que el procesamiento finlaizo Ok', 'true'),
(89, 24, 'Informa un error en la resolcu?n DNS del nombre', 'false'),
(90, 24, 'Informa que ha ocurrido un error en el procesamiento de la peticion en el servidor', 'false'),
(91, 24, 'Informa que ha ocurrido un error en el procesamiento de la peticion en el cliente', 'false'),
(92, 25, 'El cuerpo de la petici?n', 'false'),
(93, 25, 'Abriendo un socket', 'false'),
(94, 25, 'Como parte de la URL', 'true'),
(95, 25, 'No se pueden pasar parametros en una peticion GET', 'false'),
(96, 26, 'Porciones de codigo ejecutable que se envian al navegador del cliente para que este los ejecute', 'true'),
(97, 26, 'Porciones de codigo ejecutable que el cliente envia para quese ejecuten en el servidor', 'false'),
(98, 26, 'La parte del modelo de negocios que se ejecuta en el servidor', 'false'),
(99, 26, 'Ninguna de las anteriores', 'false'),
(100, 27, 'Porciones de codigo ejecutable que se envian al navegador del cliente para que este los ejecute', 'false'),
(101, 27, 'Porciones de c?digo ejecutable que se ejecutan en el servidor ante una petici?n del cliente', 'true'),
(102, 27, 'La parte del modelo de negocios que se ejecuta en el cliente', 'false'),
(103, 27, 'Ninguna de las anteriores', 'false'),
(104, 28, 'Una URL', 'true'),
(105, 28, 'Un DNS', 'false'),
(106, 28, 'Una API', 'false'),
(107, 28, 'Ninguna de las anteriores', 'false');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `nombre` varchar(255) NOT NULL,
  `anio` date NOT NULL,
  `sexo` varchar(50) NOT NULL,
  `pais` varchar(150) NOT NULL,
  `ciudad` varchar(150) NOT NULL,
  `mail` varchar(150) NOT NULL,
  `contrasenia` varchar(150) NOT NULL,
  `estaActiva` int(1) NOT NULL DEFAULT 0,
  `nombreUsuario` varchar(150) NOT NULL,
  `foto` varchar(255) NOT NULL,
  `codigo` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `nombre`, `anio`, `sexo`, `pais`, `ciudad`, `mail`, `contrasenia`, `estaActiva`, `nombreUsuario`, `foto`, `codigo`) VALUES
(1, 'Candela Fernandez', '2002-10-23', '', 'Argentina', 'Moron', 'test@test.com', 'cc03e747a6afbbcbf8be7668acfebee5', 1, 'candelax', '', '607754'),
(21, 'Maria Vazquez', '2023-09-29', '', 'Chile', 'Morón', 'test@test2k.com', '5541c7b5a06c39b267a5efae6628e003', 0, 'mariax', '', '374025'),
(22, 'Maria Vazquez', '2023-09-29', '', 'Chile', 'Morón', 'test@test22k.com', 'ae2b1fca515949e5d54fb22b8ed95575', 0, 'mariaxx', '', '863743'),
(23, 'Maria Vazquez', '2023-09-29', '', 'Chile', 'Morón', 'test@test232k.com', 'ae2b1fca515949e5d54fb22b8ed95575', 0, 'mariaxxx', '', '159839'),
(24, 'Maria Vazquez', '2023-09-29', '', 'Chile', 'Morón', 'test@test23g2k.com', 'ae2b1fca515949e5d54fb22b8ed95575', 0, 'mariaxxxx', '', '377532'),
(25, 'Candela Rocio', '2023-08-31', '', 'Uruguay', 'Morón', 'test@testing123.com', 'ae2b1fca515949e5d54fb22b8ed95575', 0, 'candelarx', '', '910597'),
(26, 'Florencia Micaela', '2006-06-14', 'Femenino', 'Chile', 'Morón', 'test1@test12.com', 'ae2b1fca515949e5d54fb22b8ed95575', 0, 'florenciax', '', '136555'),
(27, 'Candela Fernandez', '2023-10-01', 'Femenino', 'Argentina', 'Morón', 'cande.fdz12@gmail.com', 'ae2b1fca515949e5d54fb22b8ed95575', 1, 'candelaxx', '', '668899');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `preguntas`
--
ALTER TABLE `preguntas`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `respuestas`
--
ALTER TABLE `respuestas`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
