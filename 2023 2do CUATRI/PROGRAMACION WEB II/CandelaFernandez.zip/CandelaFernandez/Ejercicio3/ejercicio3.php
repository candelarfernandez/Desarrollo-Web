<?php
//EJERCICIO 3

function concatenar($texto1, $texto2){
    return "<br>". $concatena = $texto1 ." ". $texto2;
}

?>