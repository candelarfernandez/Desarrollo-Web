<?php

function incrementar(&$variable){
    echo "<br>" . ++$variable;
}

?>