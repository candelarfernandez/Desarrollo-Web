<?php

class LaBandaController {

    public function __construct() {
    }

    public function list() {
        include_once('view/labanda_view.php');
    }
}