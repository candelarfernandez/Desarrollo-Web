-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost:3307
-- Tiempo de generación: 25-09-2023 a las 23:24:36
-- Versión del servidor: 10.4.28-MariaDB
-- Versión de PHP: 8.2.4

--
-- Base de datos: `pokedex`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pokemon`
--

CREATE TABLE `pokemon` (
  `id` int(11) NOT NULL,
  `numero_identificador` int(11) NOT NULL,
  `imagen` varchar(255) NOT NULL,
  `nombre` varchar(255) NOT NULL,
  `tipo_id` int(11) DEFAULT NULL,
  `descripcion` text DEFAULT NULL,
  `tipo_id_2` int(11) DEFAULT NULL
) ;

--
-- Volcado de datos para la tabla `pokemon`
--

INSERT INTO `pokemon` (`id`, `numero_identificador`, `imagen`, `nombre`, `tipo_id`, `descripcion`, `tipo_id_2`) VALUES
(8, 1, 'Pikachu.png', 'Pikachu', 5, 'Pikachu es un Pokémon eléctrico conocido por su cola con forma de rayo.', NULL),
(9, 2, 'Bulbasaur.png', 'Bulbasaur', 12, 'Bulbasaur es un Pokémon de tipo planta y veneno que lleva una planta en su espalda que crece a medida que evoluciona.', 17),
(10, 3, 'Butterfree.png', 'Butterfree', 18, 'Butterfree es una evolución de Metapod y es conocido por sus alas coloridas que le permiten volar con gracia.', NULL),
(11, 4, 'Chansey.png', 'Chansey', 11, 'Chansey es un Pokémon amable de tipo normal que es famoso por llevar un huevo en su bolsa y por su habilidad de curación.', NULL),
(12, 5, 'Charizard.png', 'Charizard', 4, 'Charizard es una poderosa evolución de Charmander y es un dragón de fuego que escupe llamas ardientes.', 7),
(13, 6, 'Eevee.png', 'Eevee', 11, 'Eevee es un Pokémon único que tiene la capacidad de evolucionar en varias formas diferentes dependiendo de las condiciones y piedras especiales.', NULL),
(14, 7, 'Flareon.png', 'Flareon', 7, 'Flareon es una de las evoluciones de Eevee y se destaca por su tipo fuego y su pelaje peludo y ardiente.', NULL),
(15, 8, 'Jigglypuff.png', 'Jigglypuff', 11, 'Jigglypuff es un Pokémon de tipo normal y hada que es conocido por cantar una canción que hace que otros se queden dormidos.', 8),
(16, 9, 'Lapras.png', 'Lapras', 2, 'Lapras es un Pokémon de tipo agua y hielo que se asemeja a un gran monstruo marino con una caparazón en su espalda.', 9),
(17, 10, 'Meowth.png', 'Meowth', 11, 'Meowth es un Pokémon de tipo normal que se caracteriza por su moneda en la frente y la capacidad de hablar en el anime.', NULL),
(18, 11, 'Quilava.png', 'Quilava', 7, 'Quilava es una evolución de Cyndaquil y es un Pokémon de tipo fuego con una llama ardiente en su espalda.', NULL),
(19, 12, 'Squirtle.png', 'Squirtle', 2, 'Squirtle es un tierno Pokémon de tipo agua que puede disparar chorros de agua desde su boca y es uno de los Pokémon iniciales en la región de Kanto.', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipos`
--

CREATE TABLE `tipos` (
  `id` int(11) NOT NULL,
  `nombre` varchar(255) NOT NULL
);

--
-- Volcado de datos para la tabla `tipos`
--

INSERT INTO `tipos` (`id`, `nombre`) VALUES
(1, 'Planta'),
(2, 'Acero'),
(3, 'Agua'),
(4, 'Bicho'),
(5, 'Dragón'),
(6, 'Eléctrico'),
(7, 'Fantasma'),
(8, 'Fuego'),
(9, 'Hada'),
(10, 'Hielo'),
(11, 'Lucha'),
(12, 'Normal'),
(13, 'Planta'),
(14, 'Psíquico'),
(15, 'Roca'),
(16, 'Siniestro'),
(17, 'Tierra'),
(18, 'Veneno'),
(19, 'Volador');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `nombre` varchar(255) NOT NULL,
  `contraseña` varchar(255) NOT NULL
) ;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `nombre`, `contraseña`) VALUES
(1, 'Candela', '$2y$10$WzuhmBFm4w3hM4Rj30dYC.Sh3it.YkF8i0sd/tG1zoU/sNpqWqd.6');


--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `pokemon`
--
ALTER TABLE `pokemon`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_numero_identificador` (`numero_identificador`),
  ADD KEY `tipo_id` (`tipo_id`);

--
-- Indices de la tabla `tipos`
--
ALTER TABLE `tipos`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `pokemon`
--
ALTER TABLE `pokemon`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT de la tabla `tipos`
--
ALTER TABLE `tipos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `pokemon`
--
ALTER TABLE `pokemon`
  ADD CONSTRAINT `pokemon_ibfk_1` FOREIGN KEY (`tipo_id`) REFERENCES `tipos` (`id`);
COMMIT;


