<?php

require ("third-party/FPDF/fpdf.php");
class Graficos extends FPDF
{
    function Header()
    {
    }

    function Footer()
    {
    }

}