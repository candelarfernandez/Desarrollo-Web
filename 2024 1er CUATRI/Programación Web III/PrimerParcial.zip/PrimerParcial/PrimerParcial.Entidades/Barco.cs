﻿namespace PrimerParcial.Entidades
{
    public class Barco
    {
        public int id {  get; set; }
        public string nombre {  get; set; }
        public double antiguedad { get; set; }
        public int tripulacionMaxima { get; set; }
        public double tasa { get; set; }

    }
}
